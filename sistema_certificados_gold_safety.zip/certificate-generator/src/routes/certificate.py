from flask import Blueprint, request, jsonify, send_file
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PyPDF2 import PdfReader, PdfWriter
import io
import os
import tempfile
import zipfile
from datetime import datetime

certificate_bp = Blueprint('certificate', __name__)

def generate_certificate(name, cpf, training, company, hours, date):
    """
    Gera um certificado personalizado baseado no modelo fornecido
    """
    try:
        # Caminho para o modelo de certificado
        template_path = os.path.join(os.path.dirname(__file__), '..', 'static', 'certificado.pdf')
        
        # Lê o PDF modelo
        reader = PdfReader(template_path)
        writer = PdfWriter()
        
        # Cria um buffer para o PDF de overlay
        packet = io.BytesIO()
        can = canvas.Canvas(packet, pagesize=A4)
        
        # Configurações de fonte
        can.setFont("Helvetica-Bold", 24)
        
        # Nome (sempre maiúsculo) - posição aproximada baseada na imagem
        can.drawString(210, 520, name.upper())
        
        # CPF - posição aproximada
        can.setFont("Helvetica", 12)
        can.drawString(290, 465, cpf)
        
        # Treinamento - posição aproximada (pode precisar de quebra de linha)
        can.setFont("Helvetica-Bold", 12)
        training_text = f'"{training}"'
        can.drawString(145, 420, training_text)
        
        # Empresa - posição aproximada
        can.setFont("Helvetica", 12)
        company_text = f"nas dependências da Empresa {company}"
        can.drawString(145, 395, company_text)
        
        # Horas - posição aproximada
        hours_text = f"com carga horária de {hours}"
        can.drawString(850, 395, hours_text)
        
        # Data - posição aproximada
        can.setFont("Helvetica", 12)
        can.drawString(690, 340, f"São José dos Campos, {date}.")
        
        can.save()
        
        # Move to the beginning of the StringIO buffer
        packet.seek(0)
        new_pdf = PdfReader(packet)
        
        # Adiciona o overlay à primeira página
        page = reader.pages[0]
        page.merge_page(new_pdf.pages[0])
        writer.add_page(page)
        
        # Adiciona a segunda página sem modificações
        if len(reader.pages) > 1:
            writer.add_page(reader.pages[1])
        
        # Salva o PDF final
        output_buffer = io.BytesIO()
        writer.write(output_buffer)
        output_buffer.seek(0)
        
        return output_buffer
        
    except Exception as e:
        print(f"Erro ao gerar certificado: {e}")
        return None

@certificate_bp.route('/generate', methods=['POST'])
def generate_single_certificate():
    """
    Gera um certificado individual
    """
    try:
        data = request.json
        
        name = data.get('name', '')
        cpf = data.get('cpf', '')
        training = data.get('training', 'FORMAÇÃO DE SERGUANÇA EM PLATAFORMA ELEVATÓRIA MÓVEL DE TRABALHO - PEMT')
        company = data.get('company', 'Johnson Controls Hitachi')
        hours = data.get('hours', '8 (oito) horas')
        date = data.get('date', datetime.now().strftime('%d de %B de %Y'))
        
        if not name or not cpf:
            return jsonify({'error': 'Nome e CPF são obrigatórios'}), 400
        
        pdf_buffer = generate_certificate(name, cpf, training, company, hours, date)
        
        if pdf_buffer is None:
            return jsonify({'error': 'Erro ao gerar certificado'}), 500
        
        # Salva temporariamente o arquivo
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        temp_file.write(pdf_buffer.getvalue())
        temp_file.close()
        
        filename = f"certificado_{name.replace(' ', '_')}.pdf"
        
        return send_file(temp_file.name, as_attachment=True, download_name=filename, mimetype='application/pdf')
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@certificate_bp.route('/generate-batch', methods=['POST'])
def generate_batch_certificates():
    """
    Gera certificados em lote e retorna um arquivo ZIP
    """
    try:
        data = request.json
        participants = data.get('participants', [])
        
        if not participants:
            return jsonify({'error': 'Lista de participantes não pode estar vazia'}), 400
        
        # Cria um arquivo ZIP temporário
        temp_zip = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')
        
        with zipfile.ZipFile(temp_zip.name, 'w') as zip_file:
            for participant in participants:
                name = participant.get('name', '')
                cpf = participant.get('cpf', '')
                training = participant.get('training', 'FORMAÇÃO DE SERGUANÇA EM PLATAFORMA ELEVATÓRIA MÓVEL DE TRABALHO - PEMT')
                company = participant.get('company', 'Johnson Controls Hitachi')
                hours = participant.get('hours', '8 (oito) horas')
                date = participant.get('date', datetime.now().strftime('%d de %B de %Y'))
                
                if not name or not cpf:
                    continue  # Pula participantes com dados incompletos
                
                pdf_buffer = generate_certificate(name, cpf, training, company, hours, date)
                
                if pdf_buffer:
                    filename = f"certificado_{name.replace(' ', '_')}.pdf"
                    zip_file.writestr(filename, pdf_buffer.getvalue())
        
        return send_file(temp_zip.name, as_attachment=True, download_name='certificados.zip', mimetype='application/zip')
        
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

